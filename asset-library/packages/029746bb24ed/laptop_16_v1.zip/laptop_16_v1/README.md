# 16-inch Laptop — articulated, simulation-ready

A 16-inch aluminium laptop with a working hinge and every keycap on its own
spring-return slider. Delivered as URDF, MJCF and USD sharing one set of meshes,
for **Genesis, MuJoCo and NVIDIA Isaac Sim**.

## Specification

| Property | Value |
|---|---|
| Footprint (closed) | 355.7 mm x 248.1 mm, 18.5 mm high incl. feet |
| Total mass | 2.140 kg (base 1.456, lid 0.600, 78 keycaps 0.084) |
| Rigid bodies | 80 (base, lid, 78 keycaps) |
| Joints | 1 revolute lid hinge + 78 prismatic keys |
| Units / axes | metres, radians, kilograms. Z up, X to the right, Y towards the hinge |
| Materials | space-grey aluminium shell, black keyboard deck, glass trackpad, rubber feet, display with wallpaper texture |

### Joints

| Joint | Type | Range | Notes |
|---|---|---|---|
| `lid_joint` | revolute, axis -X at (0, 0.116, 0.0145) | 0 … 1.7977 rad (0 … 103 deg) | 0 = closed. MuJoCo / Genesis: hinge friction holds it at any angle under gravity. Isaac Sim: held by its angular position drive (set the target, it stays). |
| `key_joint_<key>` | prismatic, +Z, origin at the keycap centre | -0.0008 … 0 m | 0 = up. Spring return (600 N/m, ~0.5 N at full travel). Position drive included. |

Key names: letters `A`…`Z`, digits `0`…`9`, `Spacebar`, `Return`, `Shift_L/R`, `Command_L/R`,
`Option_L/R`, `Control`, `Fn`, `Tab`, `Caps_Lock`, `Delete`, `Esc`, `F1`…`F12`,
`Arrow_Up/Down/Left/Right`, punctuation (`comma`, `period`, `slash`, `minus`, `equals`,
`semicolon`, `quote`, `lbracket`, `rbracket`, `backslash`, `grave`) and the media keys.
See `macbook_pro_16.urdf` for the full list.

### Physics
`physics.json` lists mass, centre of mass and the full inertia tensor of every body
(link frame). Collision bodies are convex: the base uses a small set of convex pieces so the
keyboard well and the hinge barrel are respected, the lid and each keycap are single convex
shapes. Contact friction 0.6 / 0.5 (static / dynamic).

## Files

```
macbook_pro_16.urdf         URDF (Genesis, Isaac Sim URDF importer)
macbook_pro_16.mjcf.xml     MuJoCo model with solver settings, key springs, lid position drive and key force actuators
macbook_pro_16.usda         USD with UsdPhysics articulation, drives, collision and looks
physics.json                mass / COM / inertia per body
meshes/visual/              per-body OBJ + shared MTL (PBR extensions)
meshes/visual/parts/        per-material OBJ pieces (used by the MJCF)
meshes/collision/           convex collision pieces + manifest.json
textures/                   display wallpaper
media/                      renders and clips
examples/                   load-and-drive scripts for MuJoCo and Isaac Sim
```

## Quick start

```bash
python examples/mujoco_open_and_type.py     # lid to 103 / 60 deg, types H E L L O
python examples/mujoco_drop.py              # free-floating drop onto a floor
./python.sh examples/isaac_sim_load.py      # inside an Isaac Sim install
```

Genesis: `gs.morphs.URDF(file="macbook_pro_16.urdf")` or `gs.morphs.MJCF(file="macbook_pro_16.mjcf.xml")`.

## Notes
- The lid hinge and the keycap sliders are self-collision filtered against the base and
  against each other, as on the real product (the closed lid rests on the deck).
- Screen wallpaper is an emissive textured material; swap `textures/screen_wallpaper.png` to
  change the display content.
