"""Example: load the USD in NVIDIA Isaac Sim, open the lid and press a key.

Usage:  ./python.sh examples/isaac_sim_load.py   (from an Isaac Sim install)
"""
import os, math, numpy as np
from isaacsim import SimulationApp
app = SimulationApp({"headless": True})
from isaacsim.core.api import World
from isaacsim.core.prims import SingleArticulation
from isaacsim.core.utils.types import ArticulationAction
import omni.usd

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
omni.usd.get_context().open_stage(os.path.join(ROOT, "macbook_pro_16.usda"))
world = World(stage_units_in_meters=1.0)
world.reset()
laptop = SingleArticulation(prim_path="/macbook_pro_16", name="laptop")
laptop.initialize()
names = list(laptop.dof_names)
targets = np.zeros(laptop.num_dof, dtype=np.float32)
targets[names.index("lid_joint")] = math.radians(103.0)
targets[names.index("key_joint_A")] = -0.0008
for _ in range(300):
    laptop.apply_action(ArticulationAction(joint_positions=targets))
    world.step(render=False)
q = laptop.get_joint_positions()
print("lid angle deg:", math.degrees(q[names.index("lid_joint")]), " key A mm:", q[names.index("key_joint_A")] * 1000)
app.close()
