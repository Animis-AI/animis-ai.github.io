"""Example: drop the laptop onto a floor plane in MuJoCo (free-floating base).

Usage (from the asset root):  python examples/mujoco_drop.py
"""
import os, numpy as np, mujoco

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = mujoco.MjSpec.from_file(os.path.join(ROOT, "macbook_pro_16.mjcf.xml"))
spec.worldbody.add_geom(name="floor", type=mujoco.mjtGeom.mjGEOM_PLANE, size=[2, 2, 0.1])
base = spec.body("base_link")
base.pos = [0, 0, 0.05]
base.quat = [0.9962, 0.0, 0.0872, 0.0]
base.add_freejoint()
model = spec.compile()
data = mujoco.MjData(model)
for step in range(2000):
    mujoco.mj_step(model, data)
    if step % 400 == 0:
        print(f"t={data.time:4.2f}s  base z={data.qpos[2] * 1000:6.1f} mm  lid={data.qpos[7] * 180 / np.pi:5.2f} deg")
print("settled, max |qvel| =", float(np.abs(data.qvel).max()))
