"""Example: open the lid and type a few keys in MuJoCo.

Usage (from the asset root):  python examples/mujoco_open_and_type.py
"""
import os, mujoco

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
model = mujoco.MjModel.from_xml_path(os.path.join(ROOT, "macbook_pro_16.mjcf.xml"))
data = mujoco.MjData(model)
act = {mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_ACTUATOR, i): i for i in range(model.nu)}
jnt = {mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_JOINT, i): i for i in range(model.njnt)}

def q(name):
    return float(data.qpos[model.jnt_qposadr[jnt[name]]])

for target_deg in (103.0, 60.0):
    data.ctrl[act["lid_joint"]] = target_deg * 3.14159265 / 180.0
    for _ in range(2500):
        mujoco.mj_step(model, data)
    print(f"lid target {target_deg:5.1f} deg -> {q('lid_joint') * 180 / 3.14159265:6.2f} deg")

for key in ("H", "E", "L", "L", "O", "Spacebar"):
    data.ctrl[act[f"key_joint_{key}"]] = -1.0             # press with 1 N (cap travels 0.8 mm to its stop)
    for _ in range(150):
        mujoco.mj_step(model, data)
    down = q(f"key_joint_{key}")
    data.ctrl[act[f"key_joint_{key}"]] = 0.0              # release, the spring returns the cap
    for _ in range(150):
        mujoco.mj_step(model, data)
    print(f"key {key:8s} pressed to {down * 1000:6.3f} mm, back to {q(f'key_joint_{key}') * 1000:6.3f} mm")
